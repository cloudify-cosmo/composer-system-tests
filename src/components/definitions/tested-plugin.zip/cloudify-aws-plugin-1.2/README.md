cloudify-aws-plugin
===================

A Cloudify Plugin that provisions resources in Amazon Web Services

* Master [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-aws-plugin.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-aws-plugin)

## Usage
See [AWS Plugin](http://getcloudify.org/guide/3.2/plugin-aws.html)

# Requirements
boto AWS Python Library version 2.34.0

boto ec2 connection EC2Connection (AWS) APIVersion = '2014-10-01'
