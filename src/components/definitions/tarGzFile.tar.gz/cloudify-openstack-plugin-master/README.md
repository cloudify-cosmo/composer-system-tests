cloudify-openstack-plugin
=========================

* Master [![Circle CI](https://circleci.com/gh/cloudify-cosmo/cloudify-openstack-plugin/tree/master.svg?style=shield)](https://circleci.com/gh/cloudify-cosmo/cloudify-openstack-plugin/tree/master)
* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-openstack-plugin.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-openstack-plugin)

Cloudify OpenStack Plugin

## Usage

See [Openstack Plugin](http://getcloudify.org/guide/plugin-openstack.html)
